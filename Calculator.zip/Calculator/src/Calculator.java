import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator extends JFrame implements ActionListener {
    private static final JPanel[] rows = new JPanel[6];
    private static final JButton[] buttons = new JButton[18];
    private static final String[] btnTag = {"BackSpc", "Clear",
            "7", "8", "9", "+",
            "4", "5", "6", "-",
            "1", "2", "3", "*",
            ".", "0", "=", "/"};
    private static final Dimension disDim = new Dimension(450, 70);
    private static final Dimension smallBtnDim = new Dimension(90, 80);
    private static final Dimension bigBtnDim = new Dimension(180, 80);
    private static final JTextArea disArea = new JTextArea(1, 10);
    private static final JScrollPane disPane = new JScrollPane(disArea, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    private static final Font disFont = new Font("Times new Roman", Font.BOLD, 40);
    private static final Font btnFont = new Font("Times new Roman", Font.BOLD, 30);
    private static final ExpBuffer expBuffer = new ExpBuffer();
    private static final ExpParser expParser = new ExpParser();

    public Calculator() {
        super("Calculator");

        this.setDesign();
        int width = 500;
        int height = 600;
        this.setSize(width, height);
        this.setResizable(false);
        this.setLayout(new GridLayout(6, 5));

        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new JButton();
            buttons[i].setText(btnTag[i]);
            buttons[i].setFont(btnFont);
            buttons[i].addActionListener(this);
            if (i < 2)
                buttons[i].setPreferredSize(bigBtnDim);
            else
                buttons[i].setPreferredSize(smallBtnDim);
        }

        disArea.setEditable(false);
        disArea.setFont(disFont);
        disArea.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);

        disPane.setPreferredSize(disDim);
        disPane.setBorder(null);

        rows[0] = new JPanel();
        rows[0].setLayout(new FlowLayout(FlowLayout.CENTER));
        rows[0].add(disPane);
        this.add(rows[0]);

        for (int i = 1; i < rows.length; i++) {
            rows[i] = new JPanel();
            rows[i].setLayout(new FlowLayout(FlowLayout.CENTER, 1, 1));
            if (i == 1) {
                rows[i].add(buttons[0]);
                rows[1].add(buttons[1]);
            } else {
                for (int j = 2 + (i - 2) * 4; j < 6 + (i - 2) * 4; j++)
                    rows[i].add(buttons[j]);
            }
            this.add(rows[i]);
        }
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        Calculator cal = new Calculator();
    }

    private void setDesign() {
        try {
            UIManager.setLookAndFeel(
                    "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void clear() {
        try {
            disArea.setText("");
            expBuffer.clear();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() != buttons[0] && ae.getSource() != buttons[1] && ae.getSource() != buttons[16] && expBuffer.size() > 127)
            return;

        if (ae.getSource() == buttons[0]) //"BackSpc"
            expBuffer.del();
        else if (ae.getSource() == buttons[1]) //"Clear"
            clear();
        else if (ae.getSource() == buttons[16]) { //"="
            if (expBuffer.size() != 0) {
                String exp = expBuffer.toString();
                if (expParser.isValidExp(exp)) {
                    double doubleAns=0;
                    try {
                        doubleAns = expParser.getResult(exp);
                    }catch (ArithmeticException e) {
                        JOptionPane.showMessageDialog(this, "Error: Division By Zero");
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                    }
                    if ((long) doubleAns == doubleAns) {
                        long longAns = (long) doubleAns;
                        expBuffer.clear();
                        expBuffer.add(Long.toString(longAns));
                    } else {
                        expBuffer.clear();
                        expBuffer.add(Double.toString(doubleAns));
                    }
                    expBuffer.setIsFirst(true);
                    expBuffer.setNoDot(true);
                }
            }
        } else {
            String s = ((JButton) ae.getSource()).getText();
            expBuffer.add(s);
        }
        disArea.setText(expBuffer.toString());
    }
}
