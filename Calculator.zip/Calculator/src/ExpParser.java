import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

class ExpParser {

    private static final BigDecimal DOUBLE_MIN = BigDecimal.valueOf(-Double.MAX_VALUE);
    private static final BigDecimal DOUBLE_MAX = BigDecimal.valueOf(Double.MAX_VALUE);
    public boolean isValidExp(String exp) {
        return exp.length() != 0 && "+-*/".indexOf(exp.charAt(exp.length() - 1)) == -1;
    }

    private List<String> parseItem(String exp) {
        List<String> itemList = new ArrayList<>();

        int i = 0;
        StringBuilder numBuffer = new StringBuilder();
        while (i < exp.length()) {
            char c = exp.charAt(i);

            if ("0123456789.eE".indexOf(c) != -1) {
                numBuffer.append(c);
            } else if ("+-*/".indexOf(c) != -1) {
                // store the buffered operand
                if (numBuffer.length() > 0) {
                    if (numBuffer.charAt(0) == '.')    // .x --> 0.x
                        numBuffer.insert(0, '0');
                    else if (numBuffer.length() >= 2 && numBuffer.substring(0, 2).equals("-.")) // -.x --> -0.x
                        numBuffer.insert(1, '0');
                    if (numBuffer.charAt(numBuffer.length() - 1) == '.') // x. --> x
                        numBuffer.deleteCharAt(numBuffer.length() - 1);

                    itemList.add(numBuffer.toString());
                    numBuffer = new StringBuilder();
                }

                if (c == '-') {
                    if (itemList.isEmpty()) {
                        numBuffer.append(c);
                    } else {
                        String lastItem = itemList.get(itemList.size() - 1);
                        //negative sign
                        if (lastItem.length() == 1 && "+*/".indexOf(lastItem.charAt(0)) != -1) {
                            numBuffer.append(c);
                        }
                        //minus
                        else {
                            itemList.add("-");
                        }
                    }
                }
                //+*/
                else {
                    itemList.add(Character.toString(c));
                }
            }
            i++;
        }
        if (numBuffer.length() > 0) {
            if (numBuffer.charAt(0) == '.')    // .x --> 0.x
                numBuffer.insert(0, '0');
            else if (numBuffer.length() >= 2 && numBuffer.substring(0, 2).equals("-."))     // -.x --> -0.x
                numBuffer.insert(1, '0');
            if (numBuffer.charAt(numBuffer.length() - 1) == '.') // x. --> x
                numBuffer.deleteCharAt(numBuffer.length() - 1);

            itemList.add(numBuffer.toString());
        }
        return itemList;
    }

    public double getResult(String exp){
        List<String> itemList = this.parseItem(exp);
        List<String> rpnList = new ArrayList<>();
        Stack<String> opStack = new Stack<>();
        for (String item : itemList) {
            if (item.length() == 1 && "+-*/".indexOf(item.charAt(0)) != -1) {
                while (!opStack.isEmpty() && precedence(item) <= precedence(opStack.peek())) {
                    rpnList.add(opStack.pop());
                }
                opStack.push(item);
            } else {
                rpnList.add(item);
            }
        }
        while (!opStack.isEmpty()) {
            rpnList.add(opStack.pop());
        }
        Stack<String> rpnStack = new Stack<>();
        for (String item : rpnList) {
            if (item.length() == 1 && "+-*/".indexOf(item.charAt(0)) != -1) {
                BigDecimal op2 = new BigDecimal(rpnStack.pop());
                BigDecimal op1 = new BigDecimal(rpnStack.pop());
                BigDecimal result=BigDecimal.valueOf(0);
                switch (item) {
                    case "+":
                        result=op1.add(op2);
                        break;
                    case "-":
                        result=op1.subtract(op2);
                        break;
                    case "*":
                        result=op1.multiply(op2);
                        break;
                    case "/":
                        result=op1.divide(op2, 8, BigDecimal.ROUND_HALF_UP);
                        break;
                }
                if(DOUBLE_MIN.compareTo(result)>0 || DOUBLE_MAX.compareTo(result)<0)
                    throw new NumberFormatException("Overflow");
                else
                    rpnStack.push(Double.toString(result.doubleValue()));
            } else {
                rpnStack.push(item);
            }
        }
        return Double.parseDouble(rpnStack.pop());
    }

    private int precedence(String s) {
        if (s.length() == 0) return 0;
        if (s.length() == 1) {
            if ("*/".indexOf(s.charAt(0)) != -1) return 3;
            if ("+-".indexOf(s.charAt(0)) != -1) return 2;
        }
        return 1;
    }
}
