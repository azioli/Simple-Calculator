class ExpBuffer {
    private StringBuilder buffer;
    private boolean noDot;
    private boolean isFirst;

    public ExpBuffer() {
        buffer = new StringBuilder();
        noDot = true;
        isFirst = true;
    }

    private boolean isEmpty() {
        return buffer.length() == 0;
    }

    public int size() {
        return buffer.length();
    }

    public void setIsFirst(boolean isFirst) {
        this.isFirst = isFirst;
    }

    public void setNoDot(boolean noDot) {
        this.noDot = noDot;
    }

    public void add(String s) {
        for (int i = 0; i < s.length(); i++)
            this.add(s.charAt(i));
    }

    private void add(char c) {
        switch (c) {
            case '.':
                if (noDot) {
                    if (isFirst)
                        this.clear();
                    noDot = false;
                    isFirst = false;
                    buffer.append('.');
                }
                return;
            case '+':
            case '*':
            case '/':
                if (this.isEmpty() || (this.size()==1 && buffer.charAt(0)=='-'))
                    return;
                while (!this.isEmpty() && "+-*/".indexOf(buffer.charAt(buffer.length() - 1)) != -1) {
                    buffer.deleteCharAt(buffer.length() - 1);
                }
            case '-':
                if (!this.isEmpty() && "+-".indexOf(buffer.charAt(buffer.length() - 1)) != -1) {
                    buffer.deleteCharAt(buffer.length() - 1);
                }
                noDot = true;
                isFirst = false;
                break;
            default:
                break;
        }
        if (isFirst) {
            this.clear();
        }
        isFirst = false;
        buffer.append(c);
    }

    public String del() {
        if (buffer.length() == 0) return null;
        char c = buffer.charAt(buffer.length() - 1);
        buffer.deleteCharAt(buffer.length() - 1);
        return Character.toString(c);
    }

    public void clear() {
        if (buffer.length() != 0) {
            buffer = new StringBuilder();
        }
        noDot = true;
        isFirst = true;
    }

    public String toString() {
        return buffer.toString();
    }

}
